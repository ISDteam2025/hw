const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const { encryptText, decryptText } = require('./CommonJS/cryptoFunctions');
const fs = require('fs');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'mySecretKey12345'; // Ensure this is 16 characters long

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static('public')); // For serving static files

// Middleware to decrypt all incoming cookies
app.use((req, res, next) => {
    const decryptedCookies = {};
    for (const [key, value] of Object.entries(req.cookies)) {
        try {
            decryptedCookies[key] = decryptText(value, SECRET_KEY);
        } catch (e) {
            console.error('Cookie decryption error:', e);
        }
    }
    req.cookies = decryptedCookies;
    next();
});

// Override the res.cookie function to automatically encrypt cookies
app.use((req, res, next) => {
    const originalCookie = res.cookie;

    res.cookie = (name, value, options = {}) => {
        const encryptedValue = encryptText(value, SECRET_KEY);
        return originalCookie.call(res, name, encryptedValue, options);
    };
    next();
});

// GET endpoint for login
app.get('/login', (req, res) => {
    res.render('login', { error: null });
});

// POST endpoint for login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = JSON.parse(fs.readFileSync('users.json'));

    const user = users.find(u => u.username === username);
    if (!user) {
        return res.render('login', { error: 'User not found.' });
    }

    if (user.password !== password) {
        return res.render('login', { error: 'Wrong password.' });
    }

    // Set encrypted cookie with user ID
    res.cookie('user', user.id, { httpOnly: true });
    return res.redirect('/profile');
});

// GET endpoint for profile
app.get('/profile', (req, res) => {
    const userId = req.cookies.user;
    if (!userId) {
        return res.redirect('/login');
    }

    const users = JSON.parse(fs.readFileSync('users.json'));
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.redirect('/login');
    }

    res.render('profile', { user });
});
// GET endpoint for logout
app.get('/logout', (req, res) => {
    // Clear the 'user' cookie by setting its expiration to a past date
    res.cookie('user', '', { expires: new Date(0), httpOnly: true });
    return res.redirect('/login');
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
