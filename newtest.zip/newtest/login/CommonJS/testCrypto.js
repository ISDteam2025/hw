const { encryptText, decryptText } = require('./cryptoFunctions');

// Make sure the key is exactly 16 characters long
const key = Buffer.from('mySecretKey12345'); // This ensures it's treated as a buffer
const plainText = 'Hello, World!';

try {
    // Encrypt the plain text
    const encryptedText = encryptText(plainText, key);
    console.log('Encrypted Text:', encryptedText);

    // Decrypt the encrypted text
    const decryptedText = decryptText(encryptedText, key);
    console.log('Decrypted Text:', decryptedText);
} catch (error) {
    console.error('Error:', error.message);
}
