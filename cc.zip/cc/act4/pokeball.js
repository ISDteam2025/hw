/*
 * Pokeball Exercise
 *
 * Implements the functionality of the Pokeball webpage to show a mystery
 * Pokemon when a button is clicked.
 */
"use strict";
(function() {

  window.addEventListener("load", init);

  function init() {
    // Select the button element
    const button = document.getElementById('demo-btn');
    
    // Add an event listener to the button
    button.addEventListener('click', function() {
      // Select all image elements on the page
      const images = document.querySelectorAll('img');
      
      // Iterate over the NodeList and change the src attribute
      images.forEach(function(image) {
        image.src = 'mystery.gif';
      });
    });
  }

})();
