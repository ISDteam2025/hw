/*
 * Quadratic Equation Solver
 */
"use strict";

(function() {

  window.addEventListener("load", init);

  /**
   * init - Set up event listener for the Solve button
   */
  function init() {
    const button = document.querySelector('button');
    button.addEventListener('click', solveQuadratic);
  }

  /**
   * solveQuadratic - Solve the quadratic equation and display the result
   */
  function solveQuadratic() {
    // Get input values
    const a = parseFloat(document.getElementById('a').value);
    const b = parseFloat(document.getElementById('b').value);
    const c = parseFloat(document.getElementById('c').value);

    // Validate input
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      document.getElementById('result').textContent = "Please enter valid numbers for a, b, and c.";
      return;
    }

    // Calculate the discriminant
    const discriminant = b * b - 4 * a * c;

    let resultText = '';

    if (discriminant > 0) {
      // Two real and distinct roots
      const root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
      const root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
      resultText = `The roots are x1 = ${root1} and x2 = ${root2}.`;
    } else if (discriminant === 0) {
      // One real root
      const root = -b / (2 * a);
      resultText = `There is one real root: x = ${root}.`;
    } else {
      // No real roots (discriminant < 0)
      resultText = "There are no real roots.";
    }

    // Display the result
    document.getElementById('result').textContent = resultText;
  }

})();
