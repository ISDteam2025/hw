/*
 * Capitalizing text of all paragraphs
 */
"use strict";
(function() {

  window.addEventListener("load", init);

  function init() {
    // Select all paragraph elements
    const paragraphs = document.querySelectorAll('p');
    
    // Iterate over each paragraph and capitalize its text
    paragraphs.forEach(function(paragraph) {
      paragraph.textContent = paragraph.textContent.toUpperCase();
    });
  }

})();
