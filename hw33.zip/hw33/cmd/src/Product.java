import java.util.Scanner;

public class Product {
    private String name;
    private double price;
    private double discount;

    public Product(String name, double price, double discount) {
        this.name = name;
        this.price = price;
        this.discount = discount;
    }

    private double getImportTax() {
        return 0.1 * price;
    }

    public void displayInfo() {
        System.out.println("Product name: " + name);
        System.out.println("Unit price: $" + price);
        System.out.println("Discount: " + discount + "%");
        System.out.println("Import tax: $" + getImportTax());
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter product name: ");
        name = scanner.nextLine();
        System.out.print("Enter unit price: $");
        price = scanner.nextDouble();
        System.out.print("Enter discount percentage: ");
        discount = scanner.nextDouble();
        scanner.close();
    }

    public static void main(String[] args) {

        Product inputProduct = new Product("", 0.0, 0.0);
        inputProduct.input();
        inputProduct.displayInfo();

    }
}




