import java.util.Scanner;

class Productx {
    private String productName;
    private int productPrice;

    public Productx() {
        this.productName = "";
        this.productPrice = 0;
    }

    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter product name: ");
        this.productName = scanner.nextLine();
        System.out.print("Enter product price: ");
        this.productPrice = scanner.nextInt();
        scanner.nextLine();
       
    }
    public void display() {
        System.out.println("Product Name: " + this.productName);
        System.out.println("Product Price: $" + this.productPrice);
    }

    public static void main (String[] args) {
        Productx product1 = new Productx();
        Productx product2 = new Productx();

        System.out.println("Enter details for Product 1:");
        product1.input();
        System.out.println("Enter details for Product 2:");
        product2.input();
        System.out.println("Product 1 Information:");
        product1.display();
        System.out.println("Product 2 Information:");
        product2.display();
    }

}









