// cards.js

// Array of card image URLs (change these to your actual image paths)
const cardImages = [
    'images/2C.png',
    'images/2D.png',
    'images/3C.png',
    'images/9C.png',
    'images/7D.png'
];

// Function to get a random subset of images
function getRandomImages(images, count) {
    const shuffled = images.sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

// Function to create card elements and append them to the card board
function populateCardBoard() {
    const cardBoard = document.getElementById('card-board');
    
    if (!cardBoard) {
        console.error('Card board element not found.');
        return;
    }
    
    // Clear the existing images if any
    cardBoard.innerHTML = '';
    
    // Get a random selection of 5 images
    const randomImages = getRandomImages(cardImages, 5);
    
    randomImages.forEach((imageSrc, index) => {
        const imgElement = document.createElement('img');
        imgElement.src = imageSrc;
        imgElement.alt = `Card ${index + 1}`;
        imgElement.className = 'card';
        imgElement.addEventListener('click', () => handleCardClick(imgElement));
        cardBoard.appendChild(imgElement);
    });
}

// Function to handle card click
let lastClickedCard = null;

function handleCardClick(card) {
    if (lastClickedCard) {
        lastClickedCard.style.transform = 'scale(1)';
    }
    
    if (lastClickedCard !== card) {
        card.style.transform = 'scale(1.5)';
        lastClickedCard = card;
    } else {
        lastClickedCard = null;
    }
}

// Function to handle button click
function handleButtonClick() {
    populateCardBoard();
}

// Attach event listener to the button
document.getElementById('load-images').addEventListener('click', handleButtonClick);
