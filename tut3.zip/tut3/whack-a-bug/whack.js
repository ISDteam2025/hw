"use strict";
(function() {

  window.addEventListener("load", init);

  // Initialize the game
  function init() {
    let bugs = qsa("#bug-container img");
    for (let i = 0; i < bugs.length; i++) {
      bugs[i].addEventListener("click", whackBug);
    }
  }

  // Track whacked bugs
  let whackedBugs = new Set();
  let whackCount = 0;

  // Function to handle bug clicks
  function whackBug() {
    // Check if the bug has already been whacked
    if (whackedBugs.has(this)) {
      return;
    }

    // Change the image to the whacked version
    this.src = "bug-whacked.png";

    // Add the 'whacked' class to the image
    this.classList.add("whacked");

    // Increment the whack count and add this bug to the set of whacked bugs
    whackedBugs.add(this);
    whackCount++;

    // Update the whack count display
    id("score").textContent = whackCount;

    // Check if all bugs have been whacked
    if (whackCount === 24) {
      qs("#game p").textContent = "All bugs have been whacked!";
    }
  }

  /* --- HELPER FUNCTIONS --- */

  // Returns the element that has the ID attribute with the specified value.
  function id(name) {
    return document.getElementById(name);
  }

  // Returns first element matching selector.
  function qs(selector) {
    return document.querySelector(selector);
  }

  // Returns an array of elements matching the given query.
  function qsa(query) {
    return document.querySelectorAll(query);
  }

})();
