package edu.qldt.oop;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Student {
    private String name;
    private Date dateOfBirth;
    private String studentId;
    private double gpa;
    private List<Course> enrolledCourses;

    public Student(String name, Date dateOfBirth, String studentId) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.studentId = studentId;
        this.gpa = 0.0; // Initialize GPA to 0
        this.enrolledCourses = new ArrayList<>();
    }


    public String getName() {
        return name;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public String getStudentId() {
        return studentId;
    }

    public double getGpa() {
        return gpa;
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }
    public void registerCourse() {
        enrolledCourses.add(new JavaCourse()); // Assuming all registered courses are Java courses for simplicity
    }
    private double calculateGPA(List<Double> grades) {
        double sum = 0.0;
        for (double grade : grades) {
            sum += grade;
        }
        return sum / grades.size();
    }
    public void calculateOverallGPA(List<Double> grades) {
        this.gpa = calculateGPA(grades);
    }
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", studentId='" + studentId + '\'' +
                ", gpa=" + gpa +
                ", enrolledCourses=" + getCourseNames() +
                '}';
    }
    private List<String> getCourseNames() {
        List<String> courseNames = new ArrayList<>();
        for (Course course : enrolledCourses) {
            courseNames.add(course.getName());
        }
        return courseNames;
    }
}

interface Course {
    String getName();
}

class JavaCourse implements Course {
    @Override
    public String getName() {
        return "Java Course";
    }
}


