package edu.qldt.oop;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class test {
    public static void main(String[] args) {
        Student student1 = new Student("John Doe", new Date(), "123456");
        for (int i = 0; i < 3; i++) {
            student1.registerCourse();
        }
        System.out.println("Student information before calculating GPA:");
        System.out.println(student1);
        List<Double> grades = new ArrayList<>();
        grades.add(3.5);
        grades.add(4.0);
        grades.add(3.7);
        student1.calculateOverallGPA(grades);
        System.out.println("\nStudent information after calculating GPA:");
        System.out.println(student1);
    }
}