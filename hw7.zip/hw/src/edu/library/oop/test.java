package edu.library.oop;

import java.util.ArrayList;
import java.util.List;

public class test {
    public static void main(String[] args) {
        // Initialize library
        Library library = new Library();

        // Add items to the library
        library.addItem(new Book(1, "Java Programming", "John Doe", 500, "XYZ Publishers", 2022));
        library.addItem(new Journal(2, "Scientific Journal", "Jane Smith", 10, "2024-03-01"));
        List<String> actors = new ArrayList<>();
        actors.add("Actor 1");
        actors.add("Actor 2");
        library.addItem(new DVD(3, "Movie DVD", "Director Name", 120, "Movie Director", actors));

        // Print information of all items
        library.printAllItems();

        // Add members to the library
        library.addMember(new Member(1, "Alice", "alice@example.com"));
        library.addMember(new Member(2, "Bob", "bob@example.com"));

        // Print information of all members
        library.printAllMembers();
    }
}