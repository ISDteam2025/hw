package edu.library.oop;

import java.util.ArrayList;
import java.util.List;

// Interface for library items
interface Item {
    int getId();
    String getTitle();
    String getAuthor();
    String getType();
}

// Abstract class representing an item in the library
abstract class AbstractItem implements Item {
    private int id;
    private String title;
    private String author;
    private String type;

    public AbstractItem(int id, String title, String author, String type) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.type = type;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getType() {
        return type;
    }

    // Override toString method
    @Override
    public String toString() {
        return "ID: " + id + ", Title: " + title + ", Author: " + author + ", Type: " + type;
    }
}

// Subclass representing a book
class Book extends AbstractItem {
    private int numberOfPages;
    private String publisher;
    private int publicationYear;

    public Book(int id, String title, String author, int numberOfPages, String publisher, int publicationYear) {
        super(id, title, author, "Book");
        this.numberOfPages = numberOfPages;
        this.publisher = publisher;
        this.publicationYear = publicationYear;
    }

    // Override toString method
    @Override
    public String toString() {
        return super.toString() + ", Number of Pages: " + numberOfPages + ", Publisher: " + publisher + ", Publication Year: " + publicationYear;
    }
}

// Subclass representing a journal
class Journal extends AbstractItem {
    private int issueNumber;
    private String publicationDate;

    public Journal(int id, String title, String author, int issueNumber, String publicationDate) {
        super(id, title, author, "Journal");
        this.issueNumber = issueNumber;
        this.publicationDate = publicationDate;
    }

    // Override toString method
    @Override
    public String toString() {
        return super.toString() + ", Issue Number: " + issueNumber + ", Publication Date: " + publicationDate;
    }
}

// Subclass representing a DVD
class DVD extends AbstractItem {
    private int duration;
    private String director;
    private List<String> actors;

    public DVD(int id, String title, String author, int duration, String director, List<String> actors) {
        super(id, title, author, "DVD");
        this.duration = duration;
        this.director = director;
        this.actors = actors;
    }

    // Override toString method
    @Override
    public String toString() {
        return super.toString() + ", Duration: " + duration + " min, Director: " + director + ", Actors: " + actors;
    }
}

// Class representing a library member
class Member {
    private int id;
    private String name;
    private String email;
    private List<Item> borrowedItems;

    public Member(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.borrowedItems = new ArrayList<>();
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public List<Item> getBorrowedItems() {
        return borrowedItems;
    }

    // Method to borrow an item
    public void borrowItem(Item item) {
        borrowedItems.add(item);
    }

    // Method to return an item
    public void returnItem(Item item) {
        borrowedItems.remove(item);
    }

    // Override toString method
    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Email: " + email;
    }
}

// Class representing the library
class Library {
    private List<Item> items;
    private List<Member> members;

    public Library() {
        this.items = new ArrayList<>();
        this.members = new ArrayList<>();
    }

    // Method to add an item to the library
    public void addItem(Item item) {
        items.add(item);
    }

    // Method to remove an item from the library
    public void removeItem(Item item) {
        items.remove(item);
    }

    // Method to find an item by ID
    public Item findItemById(int id) {
        for (Item item : items) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }

    // Method to find an item by title
    public Item findItemByTitle(String title) {
        for (Item item : items) {
            if (item.getTitle().equalsIgnoreCase(title)) {
                return item;
            }
        }
        return null;
    }

    // Method to allow a member to borrow an item
    public void borrowItem(Member member, Item item) {
        member.borrowItem(item);
    }

    // Method to allow a member to return an item
    public void returnItem(Member member, Item item) {
        member.returnItem(item);
    }

    // Method to print information of all items
    public void printAllItems() {
        System.out.println("All Items:");
        for (Item item : items) {
            System.out.println(item);
        }
    }

    // Method to print information of all members
    public void printAllMembers() {
        System.out.println("All Members:");
        for (Member member : members) {
            System.out.println(member);
        }
    }

    // Method to add a member to the library
    public void addMember(Member member) {
        members.add(member);
    }
}


