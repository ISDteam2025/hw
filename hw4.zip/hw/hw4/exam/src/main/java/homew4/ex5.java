package homew4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ex5 {
    public static void main(String[] args) {
        try {

            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\ADMIN\\hw\\hw4\\exam\\src\\data.txt"));
            int N = Integer.parseInt(br.readLine());

            int[] A = new int[N];

            int[] B = new int[N];



            for (int i = 0; i < N; i++) {
                String[] line = br.readLine().split(" ");
                A[i] = Integer.parseInt(line[0]);
                B[i] = Integer.parseInt(line[1]);
            }
            br.close();
            int minTime = findShortestTime(N, A, B);

            System.out.println("Shortest possible time needed to complete the work: " + minTime);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

   
    private static int findShortestTime(int N, int[] A, int[] B) {
        int minTime = Integer.MAX_VALUE;

       
        for (int i = 0; i < N; i++) {    
            for (int j = 0; j < N; j++) {
                
                int time = Math.max(A[i], B[j]);
                minTime = Math.min(minTime, time);
            }
        }

        for (int i = 0; i < N; i++) {        
            int time = A[i] + B[i];
            minTime = Math.min(minTime, time);
        }

        return minTime;
    }
}





