package Ex1;
public abstract class Shape {
    protected String color;

    public Shape(String color) {
        this.color = color;
    }
    public abstract double getArea();
    @Override
    public String toString() {
        return "Shape[color=" + color + "]";
    }
}
  class Rectangle extends Shape {
    private int length;
    private int width;

    public Rectangle(String color, int length, int width) {
        super(color);
        this.length = length;
        this.width = width;
    }

    public double getArea() {
        return length * width;
    }
    @Override
    public String toString() {
        return "Rectangle[" + super.toString() + ", length=" + length + ", width=" + width + "]";
    }
}
  class Triangle extends Shape {
    private int base;
    private int height;

    public Triangle(String color, int base, int height) {
        super(color);
        this.base = base;
        this.height = height;
    }
    public double getArea() {
        return 0.5 * base * height;
    }
    @Override
    public String toString() {
        return "Triangle[" + super.toString() + ", base=" + base + ", height=" + height + "]";
    }
}
