package Ex1;

public class TestShape {

        public static void main(String[] args) {

            Shape rectangle = new Rectangle("Red", 5, 3);
            Shape triangle = new Triangle("Blue", 4, 6);
            System.out.println(rectangle.toString());
            System.out.println("Area of rectangle: " + rectangle.getArea());

            System.out.println(triangle.toString());
            System.out.println("Area of triangle: " + triangle.getArea());
        }

}
