package Ex2;
public abstract class Monster {
    protected String name;

    public Monster(String name) {
        this.name = name;
    }

    public abstract String attack();

    @Override
    public String toString() {
        return "Monster[" + "name=" + name + "]";
    }
}

class FireMonster extends Monster {
    public FireMonster(String name) {
        super(name);
    }
    @Override
    public String attack() {
        return name + " breathes fire!";
    }
}
class WaterMonster extends Monster {
    public WaterMonster(String name) {
        super(name);
    }
    @Override
    public String attack() {
        return name + " shoots water!";
    }
}

class StoneMonster extends Monster {
    public StoneMonster(String name) {
        super(name);
    }
    @Override
    public String attack() {
        return name + " throws a rock!";
    }
}


